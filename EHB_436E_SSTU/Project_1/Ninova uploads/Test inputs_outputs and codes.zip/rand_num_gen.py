import random


stimulusFile=open("stimulus.txt",'w')
outputFile= open("hamming_weights.txt",'w')


for i in range(1,99,1):
   stimulus=random.getrandbits(32)
   hamming_weight=stimulus.bit_count()#pyhton 3.10 method for counting number of ones
   stimulusFile.write(f"{format(stimulus,'032b')}\n")
   outputFile.write(f"{hamming_weight}\n")


stimulusFile.write("11111111111111111111111111111111\n") #edge casess
outputFile.write("32\n")
stimulusFile.write("00000000000000000000000000000000\n")
outputFile.write("0\n")